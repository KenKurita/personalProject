import React from 'react';

class Adding extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    }
  }




  render() {
    return (
      <div>
        <button>Create New Fixture</button>
      </div>
    )
  }

}

export default Adding;