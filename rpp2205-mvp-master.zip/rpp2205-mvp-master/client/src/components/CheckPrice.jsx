import React from 'react';

class Pricing extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    }
  }


  render() {
    return (
      <div>
        <button>Lookup Price</button>
      </div>
    )



  }

}

export default Pricing